package phii.gha.gamelogic;

public enum TowerStrategy
{
    FIRST, LAST, STRONGEST, WEAKEST
}
